import React, { useState } from "react";

export default function MarmitaApp() {
  const [pedidos, setPedidos] = useState([]);
  const [estoque, setEstoque] = useState({
    arroz: 10,
    feijao: 10,
    frango: 10,
    cenoura: 5,
    beterraba: 5,
    batata: 5,
    calabresa: 5,
    queijo: 2,
  });

  const [pedidoForm, setPedidoForm] = useState({
    cliente: "",
    tipo: "",
    pagamento: "Dinheiro",
    entregue: false,
  });

  const tiposMarmita = {
    "Strogonoff": { arroz: 0.15, frango: 0.15, batata: 0.05 },
    "Frango Grelhado": { arroz: 0.15, feijao: 0.1, frango: 0.15, cenoura: 0.05, beterraba: 0.05 },
    "Coxa Ensopada": { arroz: 0.15, feijao: 0.1, frango: 0.2, batata: 0.1, cenoura: 0.05, beterraba: 0.05 },
    "Calabresa Acebolada": { arroz: 0.15, feijao: 0.1, calabresa: 0.15, cenoura: 0.05, beterraba: 0.05 },
    "Parmegiana": { arroz: 0.15, feijao: 0.1, frango: 0.15, queijo: 0.05, cenoura: 0.05, beterraba: 0.05 },
    "Frango Milanesa": { arroz: 0.15, feijao: 0.1, frango: 0.15, cenoura: 0.05, beterraba: 0.05 },
  };

  const handlePedido = () => {
    const tipo = pedidoForm.tipo;
    if (!tiposMarmita[tipo]) return alert("Tipo inválido");

    const novoEstoque = { ...estoque };
    const usado = tiposMarmita[tipo];

    for (let ing in usado) {
      if (novoEstoque[ing] < usado[ing]) {
        return alert(`Estoque insuficiente de ${ing}`);
      }
      novoEstoque[ing] -= usado[ing];
    }

    setEstoque(novoEstoque);
    setPedidos([...pedidos, { ...pedidoForm, valor: 20, data: new Date().toLocaleDateString() }]);
    setPedidoForm({ cliente: "", tipo: "", pagamento: "Dinheiro", entregue: false });
  };

  const totalVendido = pedidos.reduce((acc, p) => acc + p.valor, 0);
  const entregues = pedidos.filter(p => p.entregue).length;

  return (
    <div className="p-4 max-w-3xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">Painel de Marmitas</h1>

      <div className="grid grid-cols-2 gap-4 mb-6">
        <div className="p-4 border rounded-xl shadow">
          <h2 className="font-semibold mb-2">Novo Pedido</h2>
          <input placeholder="Cliente" value={pedidoForm.cliente} onChange={e => setPedidoForm({ ...pedidoForm, cliente: e.target.value })} className="w-full border p-2 mb-2 rounded" />
          <select value={pedidoForm.tipo} onChange={e => setPedidoForm({ ...pedidoForm, tipo: e.target.value })} className="w-full border p-2 mb-2 rounded">
            <option value="">Selecione a marmita</option>
            {Object.keys(tiposMarmita).map(tipo => (
              <option key={tipo} value={tipo}>{tipo}</option>
            ))}
          </select>
          <select value={pedidoForm.pagamento} onChange={e => setPedidoForm({ ...pedidoForm, pagamento: e.target.value })} className="w-full border p-2 mb-2 rounded">
            <option>Dinheiro</option>
            <option>PIX</option>
            <option>Cartão</option>
          </select>
          <label className="block mb-2">
            <input type="checkbox" checked={pedidoForm.entregue} onChange={e => setPedidoForm({ ...pedidoForm, entregue: e.target.checked })} /> Entregue
          </label>
          <button onClick={handlePedido} className="bg-blue-600 text-white px-4 py-2 rounded w-full">Adicionar Pedido</button>
        </div>

        <div className="p-4 border rounded-xl shadow">
          <h2 className="font-semibold mb-2">Estoque Atual (kg)</h2>
          <ul className="list-disc list-inside">
            {Object.entries(estoque).map(([item, qtd]) => (
              <li key={item}>{item}: {qtd.toFixed(2)} kg</li>
            ))}
          </ul>
        </div>
      </div>

      <div className="p-4 border rounded-xl shadow mb-6">
        <h2 className="font-semibold mb-2">Resumo</h2>
        <p>Total de pedidos: {pedidos.length}</p>
        <p>Entregues: {entregues}</p>
        <p>Valor total vendido: R$ {totalVendido.toFixed(2)}</p>
      </div>

      <div className="p-4 border rounded-xl shadow">
        <h2 className="font-semibold mb-2">Pedidos Realizados</h2>
        <table className="w-full border text-sm">
          <thead>
            <tr>
              <th className="border p-1">Cliente</th>
              <th className="border p-1">Tipo</th>
              <th className="border p-1">Pagamento</th>
              <th className="border p-1">Data</th>
              <th className="border p-1">Valor</th>
              <th className="border p-1">Entregue</th>
            </tr>
          </thead>
          <tbody>
            {pedidos.map((p, i) => (
              <tr key={i}>
                <td className="border p-1">{p.cliente}</td>
                <td className="border p-1">{p.tipo}</td>
                <td className="border p-1">{p.pagamento}</td>
                <td className="border p-1">{p.data}</td>
                <td className="border p-1">R$ {p.valor}</td>
                <td className="border p-1">{p.entregue ? "Sim" : "Não"}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}